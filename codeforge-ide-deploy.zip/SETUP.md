# CodeForge IDE - Deployment Setup

## Quick Start

1. Install dependencies:
   ```bash
   bun install
   ```

2. Configure environment:
   ```bash
   cp .env.example .env
   cp .env.local.example .env.local
   ```
   Edit `.env` and `.env.local` to add your Gemini API key.

3. Initialize the database:
   ```bash
   bun run db:push
   ```

4. Install terminal service dependencies:
   ```bash
   cd mini-services/terminal-service && npm install && cd ../..
   ```

5. Start the development server:
   ```bash
   bun run dev
   ```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | SQLite database path | Yes |
| `GEMINI_API_KEY` | Google Gemini API key | Yes (for AI features) |

## AI Features

The AI Assistant uses a hybrid approach:
- **Primary**: Google Gemini API (gemini-2.0-flash)
- **Fallback**: z-ai-web-dev-sdk (automatic if Gemini is unavailable)

The Gemini API key is stored server-side only and never exposed to the client.

## Ports

| Service | Port |
|---------|------|
| Next.js App | 3000 |
| Terminal WebSocket | 3002 |
| Executor Service | 3001 |

## Production Build

```bash
bun run build
bun start
```
